<footer>
    <p>&copy; 2024 Ваш сайт. Всі права захищені.</p>
</footer>
</div>
</body>
</html>
